const filterInput = document.getElementById('filterInput');
const table = document.getElementById('myTable');
const rows = table.getElementsByTagName('tr');

filterInput.addEventListener('input', function() {
  const filterValue = filterInput.value.toUpperCase();
  
  for (let i = 1; i < rows.length; i++) { // 跳過標題行，從第二行開始檢查
    let shouldDisplay = false;
    const cells = rows[i].getElementsByTagName('td');
    
    for (let j = 0; j < cells.length; j++) {
      const cellText = cells[j].textContent || cells[j].innerText;
      
      if (cellText.toUpperCase().indexOf(filterValue) > -1) {
        shouldDisplay = true;
        break;
      }
    }
    
    rows[i].style.display = shouldDisplay ? '' : 'none';
  }
});