(function($) {

	"use strict";

})(jQuery);