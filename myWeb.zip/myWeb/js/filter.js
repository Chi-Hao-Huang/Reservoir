document.addEventListener("DOMContentLoaded", function() {
  const filterInput = document.getElementById("filterInput");
  const dataTable = document.getElementById("myTable");

  filterInput.addEventListener("input", function() {
    const filterValues = filterInput.value.toLowerCase().split(" ");
    const rows = dataTable.getElementsByTagName("tr");

    for (let i = 1; i < rows.length; i++) { // Start from 1 to skip the header row
      const row = rows[i];
      let rowVisible = true;

      const cells = row.getElementsByTagName("td");
      for (let j = 0; j < cells.length; j++) {
        const cell = cells[j];
        const cellText = cell.textContent.toLowerCase();
        let cellContainsFilterValues = true;

        for (const filterValue of filterValues) {
          if (!cellText.includes(filterValue)) {
            cellContainsFilterValues = false;
            break;
          }
        }

        if (cellContainsFilterValues) {
          rowVisible = true;
          break; // If at least one cell matches all filter values, show the row
        } else {
          rowVisible = false;
        }
      }

      row.style.display = rowVisible ? "" : "none";
    }
  });
});