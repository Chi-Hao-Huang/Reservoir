TT_ADOBE_IDS
============

A list of valid values for the 'encoding_id' for TT_PLATFORM_ADOBE
charmaps. This is a FreeType-specific extension!

.. data:: TT_ADOBE_ID_STANDARD	

  Adobe standard encoding.


.. data:: TT_ADOBE_ID_EXPERT	

  Adobe expert encoding.


.. data:: TT_ADOBE_ID_CUSTOM	

  Adobe custom encoding.


.. data:: TT_ADOBE_ID_LATIN_1	

  Adobe Latin 1 encoding.

