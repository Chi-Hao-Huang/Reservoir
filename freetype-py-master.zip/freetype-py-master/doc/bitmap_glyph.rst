.. currentmodule:: freetype

Bitmap glyph
============
.. autoclass:: BitmapGlyph
   :members:
