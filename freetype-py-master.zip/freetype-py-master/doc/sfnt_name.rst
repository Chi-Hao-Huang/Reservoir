.. currentmodule:: freetype

SFNT name
==========
.. autoclass:: SfntName
   :members:
