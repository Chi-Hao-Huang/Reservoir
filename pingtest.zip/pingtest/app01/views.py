from django.shortcuts import render
from django.http import JsonResponse

from ping3 import ping
import threading


def home(request):

    return render(request, 'index.html')


def ping_view(request):
    ip_list = ['8.8.8.8', '1.1.1.1', '208.67.222.222', '9.9.9.9', '192.168.1.1', '192.168.1.2', '192.168.1.3', '192.168.1.4']  # 用您的IP地址替换这些示例地址
    results = {}

    def ping_ip(ip):
        response_time = ping(ip)
        if response_time is not None:
            results['ip_' + ip.replace('.','_')] = True
        else:
            results['ip_' + ip.replace('.','_')] = False

    threads = []
    for ip in ip_list:
        thread = threading.Thread(target=ping_ip, args=(ip,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    return render(request, 'index.html', {'results': results})