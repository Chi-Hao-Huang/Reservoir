# Animated Progress Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/pierrinho/pen/VVGezJ](https://codepen.io/pierrinho/pen/VVGezJ).

